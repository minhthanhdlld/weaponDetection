# FURQAN > 2024-01-17 1:52am
https://universe.roboflow.com/detection-o2goy/furqan

Provided by a Roboflow user
License: Public Domain

